﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WTS.Entities.Enums;

namespace WTS.Entities.Main.Enums
{
    public enum Species
    {
        Squirrel,
        Zebra,
        Crocodile,
        Snake,
        Spider,
        Scorpion,
        Frog, 
        Salamander
        

        

    }
}
